package com.citiustech.hms;

import java.sql.SQLException;
import java.util.Scanner;

import com.citiustech.hms.authenticate.AdminAuthentication;
import com.citiustech.hms.exception.HMSCustomException;

public class MainHMS {

	private static Scanner scanner = new Scanner(System.in);
	 

	public static void checkAdminLoggedIn() throws HMSCustomException {
		System.out.print("Enter UserName : ");
		String userName = scanner.nextLine();

		System.out.println("");
		System.out.print("Enter Password : ");
		String password = scanner.nextLine();

		AdminAuthentication authentication = new AdminAuthentication();
		boolean loggedIn = authentication.isLoggedIn(userName, password);

		if (loggedIn) {
			System.out.println("Successfully Logged In");
			SwitchModule module = new SwitchModule();
			module.doSwitchModule();
			
		} else {
			throw new HMSCustomException("Please enter Valid Credentials");
		}

	}

	public static void main(String[] args) throws SQLException {

		try {
			System.out.println("-----------------------Enter Login Details-----------------------");
			checkAdminLoggedIn();
			System.out.println("");
			System.out.println("------------------------------------------------------------------");
		} catch (HMSCustomException e) {
			System.out.println(e.getMessage());
		}

	}

}
