package com.citiustech.hms.model;

public class Patient {

	private int patientId;
	private String patientName;
	private String address;
	private int age;
	private long phoneNumber;

	public int getPatientId() {
		return patientId;
	}

	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public long getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public Patient(int patientId, String patientName, String address, int age, long phoneNumber) {
		super();
		this.patientId = patientId;
		this.patientName = patientName;
		this.address = address;
		this.age = age;
		this.phoneNumber = phoneNumber;
	}

	public Patient() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Patient [patientId=" + patientId + ", patientName=" + patientName + ", Address=" + address + ", age="
				+ age + ", phoneNumber=" + phoneNumber + "]";
	}

}
