package com.citiustech.hms.model;

public class Doctor {

	private int doctorId;
	private String doctorName;
	private String address;
	private String speciality;
	private long phoneNumber;

	public int getDoctorId() {
		return doctorId;
	}

	public void setDoctorId(int doctorId) {
		this.doctorId = doctorId;
	}

	public String getDoctorName() {
		return doctorName;
	}

	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getSpeciality() {
		return speciality;
	}

	public void setSpeciality(String speciality) {
		this.speciality = speciality;
	}

	public long getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public Doctor(int doctorId, String doctorName, String address, String speciality, long phoneNumber) {
		super();
		this.doctorId = doctorId;
		this.doctorName = doctorName;
		this.address = address;
		this.speciality = speciality;
		this.phoneNumber = phoneNumber;
	}

	public Doctor() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Doctor [doctorId=" + doctorId + ", doctorName=" + doctorName + ", Address=" + address + ", Speciality="
				+ speciality + ", phoneNumber=" + phoneNumber + "]";
	}

}
