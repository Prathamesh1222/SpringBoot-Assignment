package com.citiustech.hms.authenticate;

import java.util.LinkedHashSet;
import java.util.Set;

import com.citiustech.hms.model.Admin;

public class AdminAuthentication {

	private Set<Admin> adminSet = null;

	public boolean isLoggedIn(String userName, String password) {

		boolean flag = false;

		adminSet = getAdminDetailsToValidate();

		for (Admin a : adminSet) {

			System.out.println(a);

			if (a.getUserName().equals(userName) & a.getPassword().equals(password)) {
				return true;
			}
		}
		return flag;

	}

	public Set<Admin> getAdminDetailsToValidate() {

		adminSet = new LinkedHashSet<Admin>();

		adminSet.add(new Admin("Abc", "AAA"));
		adminSet.add(new Admin("Abc@123", "abc"));
		adminSet.add(new Admin("Lmn@123", "lmn"));
		adminSet.add(new Admin("Kit@1234", "kit"));

		System.out.println(adminSet);

		return adminSet;

	}

}
