package com.citiustech.hms.exception;

public class HMSCustomException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public HMSCustomException(String message) {
		super(message);
	}

}
