package com.citiustech.hms.serviceImpl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import com.citiustech.hms.model.Doctor;
import com.citiustech.hms.service.DoctorService;

public class DoctorServiceImpl implements DoctorService {

	static Connection connection = null;
	static Statement statement = null;
	static PreparedStatement preparedStatement = null;
	static Scanner input = new Scanner(System.in);
	static Scanner str = new Scanner(System.in);
	private Doctor doctor = null;
	private List<Doctor> doctors = null;

	@Override
	public int addDoctor(Doctor doctor) {

		int row = 0;

		try {
			connection = DriverManager.getConnection(
					"jdbc:sqlserver://CTAADPG02S00A\\SQLEXPRESS2019;databaseName=December2023;user=sa;password=password_123;");

			preparedStatement = connection.prepareStatement(
					"INSERT INTO Doctor (doctorName, address, speciality, phoneNumber) VALUES(?,?,?,?)");

			preparedStatement.setString(1, doctor.getDoctorName());
			preparedStatement.setString(2, doctor.getAddress());
			preparedStatement.setString(3, doctor.getSpeciality());
			preparedStatement.setLong(4, doctor.getPhoneNumber());

			row = preparedStatement.executeUpdate();
			System.out.println(row + "rows affected");
			connection.close();
			return row;
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}

		return 0;
	}

	@Override
	public int updateDoctor() {
		int row = 0;

		try {
			connection = DriverManager.getConnection(
					"jdbc:sqlserver://CTAADPG02S00A\\SQLEXPRESS2019;databaseName=December2023;user=sa;password=password_123;");

			preparedStatement = connection.prepareStatement(
					"UPDATE Doctor SET doctorName = ?, address = ?, speciality = ?, phoneNumber = ? WHERE doctorID = ?");

			System.out.println("Enter doctor ID : ");
			int doctorId = input.nextInt();
			System.out.println("Enter Doctor Name : ");
			String dName = str.nextLine();
			System.out.println("Enter Doctor Address : ");
			String dAddress = str.nextLine();
			System.out.println("Enter Doctor Speciality : ");
			String dSpeciality = str.nextLine();
			System.out.println("Enter Doctor Phone Number : ");
			Long dPhoneNumber = input.nextLong();

			preparedStatement.setInt(5, doctorId);
			preparedStatement.setString(1, dName);
			preparedStatement.setString(2, dAddress);
			preparedStatement.setString(3, dSpeciality);
			preparedStatement.setLong(4, dPhoneNumber);

			row = preparedStatement.executeUpdate();
			connection.close();
			return row;
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}

		return 0;
	}

	@Override
	public int deleteDoctor(Integer doctorId) {

		int row = 0;
		try {
			connection = DriverManager.getConnection(
					"jdbc:sqlserver://CTAADPG02S00A\\SQLEXPRESS2019;databaseName=December2023;user=sa;password=password_123;");

			preparedStatement = connection.prepareStatement("DELETE FROM Doctor WHERE doctorID = ?");
//			System.out.print("Please Enter the Doctor ID = ");
//			int docId = input.nextInt();
			preparedStatement.setInt(1, doctorId);

			int deleted = preparedStatement.executeUpdate();
			connection.close();
			return deleted;
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return row;
	}

	@Override
	public List<Doctor> getDoctor() {
		doctors = new ArrayList<Doctor>();
		try {
			connection = DriverManager.getConnection(
					"jdbc:sqlserver://CTAADPG02S00A\\SQLEXPRESS2019;databaseName=December2023;user=sa;password=password_123;");

			statement = connection.createStatement();
			ResultSet resultSet = statement.executeQuery("SELECT * FROM Doctor");

			while (resultSet.next()) {

				doctor = new Doctor(resultSet.getInt("doctorID"), resultSet.getString("doctorName"),
						resultSet.getString("address"), resultSet.getString("speciality"),
						resultSet.getLong("phoneNumber"));

				doctors.add(doctor);
			}
			connection.close();
			return doctors;

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return doctors;
	}

	@Override
	public Doctor getDoctorById(Integer doctorId) {

		try {
			connection = DriverManager.getConnection(
					"jdbc:sqlserver://CTAADPG02S00A\\SQLEXPRESS2019;databaseName=December2023;user=sa;password=password_123;");

			preparedStatement = connection.prepareStatement(
					"SELECT doctorID, doctorName, address, speciality, phoneNumber FROM Doctor WHERE doctorID = ?");
			preparedStatement.setInt(1, doctorId);

			ResultSet resultSet = preparedStatement.executeQuery();

			while (resultSet.next()) {

				doctor = new Doctor(resultSet.getInt("doctorID"), resultSet.getString("doctorName"),
						resultSet.getString("address"), resultSet.getString("speciality"),
						resultSet.getLong("phoneNumber"));

				return doctor;
			}
			connection.close();
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return doctor;
	}

}
