package com.citiustech.hms.serviceImpl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import com.citiustech.hms.model.Patient;
import com.citiustech.hms.service.PatientService;

public class PatientServiceImpl implements PatientService {

	static Connection connection = null;
	static Statement statement = null;
	static PreparedStatement preparedStatement = null;
	static Scanner input = new Scanner(System.in);
	static Scanner str = new Scanner(System.in);
	private Patient patient = null;
	private List<Patient> patients = null;

	@Override
	public int addPatient(Patient patient) {

		int row = 0;

		try {
			connection = DriverManager.getConnection(
					"jdbc:sqlserver://CTAADPG02S00A\\SQLEXPRESS2019;databaseName=December2023;user=sa;password=password_123;");

			preparedStatement = connection
					.prepareStatement("INSERT INTO Patient (patientName, address, age, phoneNumber) VALUES(?,?,?,?)");

			preparedStatement.setString(1, patient.getPatientName());
			preparedStatement.setString(2, patient.getAddress());
			preparedStatement.setInt(3, patient.getAge());
			preparedStatement.setLong(4, patient.getPhoneNumber());

			row = preparedStatement.executeUpdate();
			System.out.println(row + "rows affected");
			connection.close();
			return row;
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}

		return row;
	}

	@Override
	public int updatePatient() {
		int row = 0;

		try {
			connection = DriverManager.getConnection(
					"jdbc:sqlserver://CTAADPG02S00A\\SQLEXPRESS2019;databaseName=December2023;user=sa;password=password_123;");

			preparedStatement = connection.prepareStatement(
					"UPDATE Patient SET patientName = ?, address = ?, age = ?, phoneNumber = ? WHERE patientId = ?");

			System.out.println("Enter Patient ID : ");
			int patientId = input.nextInt();
			System.out.println("Enter Patient Name : ");
			String name = str.nextLine();
			System.out.println("Enter Patient Address : ");
			String address = str.nextLine();
			System.out.println("Enter Patient Speciality : ");
			int age = input.nextInt();
			System.out.println("Enter Patient Phone Number : ");
			Long phoneNumber = input.nextLong();

			preparedStatement.setInt(5, patientId);
			preparedStatement.setString(1, name);
			preparedStatement.setString(2, address);
			preparedStatement.setInt(3, age);
			preparedStatement.setLong(4, phoneNumber);

			row = preparedStatement.executeUpdate();
			connection.close();
			return row;
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}

		return 0;
	}

	@Override
	public int deletePatient(Integer patientId) {

		int row = 0;
		try {
			connection = DriverManager.getConnection(
					"jdbc:sqlserver://CTAADPG02S00A\\SQLEXPRESS2019;databaseName=December2023;user=sa;password=password_123;");

			preparedStatement = connection.prepareStatement("DELETE FROM Patient WHERE patientId = ?");
			preparedStatement.setInt(1, patientId);

			int deleted = preparedStatement.executeUpdate();
			connection.close();
			return deleted;
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return row;
	}

	@Override
	public List<Patient> getPatient() {
		patients = new ArrayList<Patient>();
		try {
			connection = DriverManager.getConnection(
					"jdbc:sqlserver://CTAADPG02S00A\\SQLEXPRESS2019;databaseName=December2023;user=sa;password=password_123;");

			statement = connection.createStatement();
			ResultSet resultSet = statement.executeQuery("SELECT * FROM Patient");

			while (resultSet.next()) {

				patient = new Patient(resultSet.getInt("patientID"), resultSet.getString("patientName"),
						resultSet.getString("address"), resultSet.getInt("age"), resultSet.getLong("phoneNumber"));

				patients.add(patient);
			}
			connection.close();
			return patients;

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return patients;
	}

	@Override
	public Patient getPatientById(Integer patientId) {

		try {
			connection = DriverManager.getConnection(
					"jdbc:sqlserver://CTAADPG02S00A\\SQLEXPRESS2019;databaseName=December2023;user=sa;password=password_123;");

			preparedStatement = connection.prepareStatement(
					"SELECT patientId, patientName, address, age, phoneNumber FROM Patient WHERE patientId = ?");
			preparedStatement.setInt(1, patientId);

			ResultSet resultSet = preparedStatement.executeQuery();

			while (resultSet.next()) {

				patient = new Patient(resultSet.getInt("patientId"), resultSet.getString("patientName"),
						resultSet.getString("address"), resultSet.getInt("age"), resultSet.getLong("phoneNumber"));

				return patient;
			}
			connection.close();
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return patient;
	}

}
