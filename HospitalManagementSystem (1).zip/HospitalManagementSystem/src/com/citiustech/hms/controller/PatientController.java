package com.citiustech.hms.controller;

import java.util.List;
import java.util.Scanner;

import com.citiustech.hms.exception.HMSCustomException;
import com.citiustech.hms.model.Patient;
import com.citiustech.hms.service.PatientService;
import com.citiustech.hms.serviceImpl.PatientServiceImpl;

public class PatientController {
	private static Scanner input = new Scanner(System.in);

	private PatientService patientService = new PatientServiceImpl();

	private Patient patient = null;

	public void addPatinet() {
		System.out.println("------------------Enter Patient Details------------------");

		System.out.println("Enter Patient Name : ");
		String name = input.nextLine();
		System.out.println("Enter Patient Address : ");
		String address = input.nextLine();
		System.out.println("Enter Patient Age : ");
		int age = input.nextInt();
		System.out.println("Enter Patient Phone Number : ");
		Long phoneNumber = input.nextLong();

		patient = new Patient();
		patient.setPatientName(name);
		patient.setAddress(address);
		patient.setAge(age);
		patient.setPhoneNumber(phoneNumber);
		
		patientService.addPatient(patient);
	}

	public void updatePatient() throws HMSCustomException {

		int isUpdated = patientService.updatePatient();

		if (isUpdated > 0) {
			System.out.println("Patient Details updated");
		} else {
			throw new HMSCustomException("You have entered invalid Patient ID");
		}

	}

	public void deletePatient() throws HMSCustomException {

		System.out.println("Please valid Patient ID : ");
		int patientId = input.nextInt();

		int isDeleted = patientService.deletePatient(patientId);
		if (isDeleted > 0) {
			System.out.println("Patient Deleted");
		} else {
			throw new HMSCustomException("You have entered invalid patient ID : " + patientId);
		}

	}

	public void getPatient() throws HMSCustomException {
		List<Patient> patients = patientService.getPatient();
		if (!patients.contains(null)) {
			patients.forEach(p -> System.out.println(p));
		} else {
			throw new HMSCustomException("Patient Data Not Found");
		}
	}

	public void getPatientById() throws HMSCustomException {
		System.out.println("Please valid patient ID : ");
		int patientId = input.nextInt();

		patient = patientService.getPatientById(patientId);

		if (!patient.equals(null)) {
			System.out.println(patient);
		} else {
			throw new HMSCustomException("You have entered invalid Patient ID : " + patientId);
		}
	}


}
