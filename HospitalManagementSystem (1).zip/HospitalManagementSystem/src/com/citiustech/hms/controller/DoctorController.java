package com.citiustech.hms.controller;

import java.util.List;
import java.util.Scanner;

import com.citiustech.hms.exception.HMSCustomException;
import com.citiustech.hms.model.Doctor;
import com.citiustech.hms.service.DoctorService;
import com.citiustech.hms.serviceImpl.DoctorServiceImpl;

public class DoctorController {

	private static Scanner input = new Scanner(System.in);

	private DoctorService doctorService = new DoctorServiceImpl();

	private Doctor doctor = null;

	public void addDoctor() {
		System.out.println("Enter Doctor Details");

		System.out.println("Enter Doctor Name : ");
		String dName = input.nextLine();
		System.out.println("Enter Doctor Address : ");
		String dAddress = input.nextLine();
		System.out.println("Enter Doctor Speciality : ");
		String dSpeciality = input.nextLine();
		System.out.println("Enter Doctor Phone Number : ");
		Long dPhoneNumber = input.nextLong();

		doctor = new Doctor();
		doctor.setDoctorName(dName);
		doctor.setAddress(dAddress);
		doctor.setSpeciality(dSpeciality);
		doctor.setPhoneNumber(dPhoneNumber);

		doctorService.addDoctor(doctor);

	}

	public void updateDoctor() throws HMSCustomException {

//		System.out.println("Enter Doctor Details");
//		System.out.println("Please valid doctor ID : ");
//		int doctorId = input.nextInt();

//		System.out.println("Enter Doctor Name : ");
//		String dName = input.nextLine();
//		System.out.println("Enter Doctor Address : ");
//		String dAddress = input.nextLine();
//		System.out.println("Enter Doctor Speciality : ");
//		String dSpeciality = input.nextLine();
//		System.out.println("Enter Doctor Phone Number : ");
//		Long dPhoneNumber = input.nextLong();
//
//		doctor = new Doctor();
//		doctor.setDoctorName(dName);
//		doctor.setAddress(dAddress);
//		doctor.setSpeciality(dSpeciality);
//		doctor.setPhoneNumber(dPhoneNumber);

		int isUpdated = doctorService.updateDoctor();

		if (isUpdated > 0) {
			System.out.println("Doctor Details updated");
		} else {
			throw new HMSCustomException("You have entered invalid doctor ID");
		}

	}

	public void deleteDoctor() throws HMSCustomException {

		System.out.println("Please valid doctor ID : ");
		int doctorId = input.nextInt();

		int isDeleted = doctorService.deleteDoctor(doctorId);
		if (isDeleted > 0) {
			System.out.println("Doctor Deleted");
		} else {
			throw new HMSCustomException("You have entered invalid doctor ID : " + doctorId);
		}

	}

	public void getDoctor() throws HMSCustomException {
		List<Doctor> docs = doctorService.getDoctor();
		if (!docs.contains(null)) {
			docs.forEach(d -> System.out.println(d));
		} else {
			throw new HMSCustomException("Doctor Data Not Available");
		}
	}

	public void getDotorById() throws HMSCustomException {
		System.out.println("Please valid doctor ID : ");
		int doctorId = input.nextInt();

		doctor = doctorService.getDoctorById(doctorId);

		if (!doctor.equals(null)) {
			System.out.println(doctor);
		} else {
			throw new HMSCustomException("You have entered invalid doctor ID : " + doctorId);
		}
	}

}
