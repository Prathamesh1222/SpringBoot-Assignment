package com.citiustech.hms.service;

import java.util.List;

import com.citiustech.hms.model.Patient;

public interface PatientService {
	public int addPatient(Patient patient);

	public int updatePatient();

	public int deletePatient(Integer patientId);

	public List<Patient> getPatient();

	public Patient getPatientById(Integer patientId);
}
