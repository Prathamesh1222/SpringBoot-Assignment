package com.citiustech.hms.service;

import java.util.List;

import com.citiustech.hms.model.Doctor;

public interface DoctorService {

	public int addDoctor(Doctor doctor);

	public int updateDoctor();

	public int deleteDoctor(Integer doctorId);

	public List<Doctor> getDoctor();

	public Doctor getDoctorById(Integer doctorId);

}
