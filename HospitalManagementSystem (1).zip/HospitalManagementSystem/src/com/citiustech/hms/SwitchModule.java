package com.citiustech.hms;

import java.util.Scanner;

import com.citiustech.hms.controller.DoctorController;
import com.citiustech.hms.controller.PatientController;
import com.citiustech.hms.exception.HMSCustomException;

public class SwitchModule {

	private DoctorController doctorcontroller = new DoctorController();
	private PatientController patientController = new PatientController();
	private static Scanner input = new Scanner(System.in);

	public void doSwitchModule() throws HMSCustomException {
		System.out.println("-----------------------Please Select Module-----------------------");
		System.out.println("1. Doctor\r\n" + "2. Patient\r\n" + "0. Exit");
		System.out.println("------------------------------------------------------------------");

		int choiceModule = input.nextInt();

		switch (choiceModule) {
		case 1:
			System.out.println("--------------------Doctor--------------------");
			getDoctorFunctionality();
			break;
		case 2:
			System.out.println("--------------------Patient--------------------");
			getPatientFunctionality();
			break;
		case 0:
			input.close();
			System.out.println("Exit");
			break;

		}
	}

	public void getDoctorFunctionality() throws HMSCustomException {

		int i = 0;
		int terminated = 0;

		do {
			System.out.println("-----------------------Doctor-----------------------");
			System.out.println("1. Add Doctor\r\n" + "2. Update Doctor\r\n" + "3. Delete Doctor\r\n"
					+ "4. Get Doctors\r\n" + "5. Get Doctor by ID\r\n" + "0. Go back to previous menu\r\n");
			int choice = input.nextInt();
			System.out.println("----------------------------------------------------");

			switch (choice) {
			case 1:
				doctorcontroller.addDoctor();
				break;
			case 2:
				System.out.println("Update Doctor");
				doctorcontroller.updateDoctor();
				break;
			case 3:
				System.out.println("Delete Doctor");
				doctorcontroller.deleteDoctor();
				break;
			case 4:
				System.out.println("Get Doctors");
				doctorcontroller.getDoctor();
				break;
			case 5:
				System.out.println("Get Doctor by ID");
				doctorcontroller.getDotorById();
				break;
			case 0:
				System.out.println("Go back to previous menu");
				doSwitchModule();
				break;
			}
			if (choice == 0) {
				terminated = 1;
				break;
			} else {
				System.out.println("Restarted");
			}
		} while (i <= 20);

		if (terminated == 1) {
			System.out.println("Exit");
			input.close();
		}

	}

	public void getPatientFunctionality() throws HMSCustomException {

		int i = 0;
		int terminated = 0;

		do {
			System.out.println("-----------------------Doctor-----------------------");
			System.out.println("1. Add Patient\r\n" + "2. Update Patient\r\n" + "3. Delete Patient\r\n"
					+ "4. Get Patients\r\n" + "5. Get Patient by ID\r\n" + "0. Go back to previous menu\r\n");
			int choice = input.nextInt();
			System.out.println("----------------------------------------------------");

			switch (choice) {
			case 1:
				patientController.addPatinet();
				break;
			case 2:
				System.out.println("Update Patient");
				patientController.updatePatient();
				break;
			case 3:
				System.out.println("Delete Patient");
				patientController.deletePatient();
				break;
			case 4:
				System.out.println("Get Patients");
				patientController.getPatient();
				break;
			case 5:
				System.out.println("Get Patient by ID");
				patientController.getPatientById();
				break;
			case 0:
				System.out.println("Go back to previous menu");
				doSwitchModule();
				break;
			}
			if (choice == 0) {
				terminated = 1;
				break;
			} else {
				System.out.println("Restarted");
			}
		} while (i <= 20);

		if (terminated == 1) {
			System.out.println("Exit");
			input.close();
		}

	}
}
