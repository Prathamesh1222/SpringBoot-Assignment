package com.hospitalModule.repository;

import com.hospitalModule.model.Physician;
import com.hospitalModule.model.UserInfo;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface PhysicianRepository extends JpaRepository<Physician, Long> {
    Optional<Physician> findByEmail(String email);

}

