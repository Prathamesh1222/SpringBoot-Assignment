package com.hospitalModule.model;

public class AppointmentRequest {
    private Patient patient;
    private Physician physician;
    private String appointmentTime;

    public AppointmentRequest() {
    }

    public AppointmentRequest(Patient patient, Physician physician, String appointmentTime) {
        this.patient = patient;
        this.physician = physician;
        this.appointmentTime = appointmentTime;
    }
// Getters and Setters

    public String getAppointmentTime() {
        return appointmentTime;
    }

    public void setAppointmentTime(String appointmentTime) {
        this.appointmentTime = appointmentTime;
    }

    public Physician getPhysician() {
        return physician;
    }

    public void setPhysician(Physician physician) {
        this.physician = physician;
    }

    public Patient getPatient() {
        return patient;
    }

    public void setPatient(Patient patient) {
        this.patient = patient;
    }
}

