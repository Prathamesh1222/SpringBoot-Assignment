package com.hospitalModule.controller;

import com.hospitalModule.model.AuthRequest;
import com.hospitalModule.model.UserInfo;
import com.hospitalModule.security.JwtService;
import com.hospitalModule.security.UserInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/auth")
public class UserController {

    @Autowired
    private UserInfoService service;

    @Autowired
    private JwtService jwtService;

    @Autowired
    private AuthenticationManager authenticationManager;

    @GetMapping("/welcome")
    public String welcome() {
        return "Welcome this endpoint is not secure";
    }

    @GetMapping("/add")
    public String showAddUserForm(Model model) {
        // Create a list of roles to display in the dropdown
        model.addAttribute("roles", new String[] { "PATIENT", "PHYSICIAN", "ADMIN" });

        // Initialize a new UserInfo object for binding
        model.addAttribute("userInfo", new UserInfo());
        return "addUser";  // Return Thymeleaf template (addUser.html)
    }

    @PostMapping("/addNewUser")
    public String addNewUser(UserInfo userInfo) {
        // Call your service method to save the user
        service.addUser(userInfo);
        return "redirect:/auth/success"; // Redirect to success page
    }
    @GetMapping("/user/userProfile")
    @PreAuthorize("hasAuthority('PATIENT')")
    public String userProfile() {
        return "Welcome to User Profile";
    }

    @GetMapping("/admin/adminProfile")
    @PreAuthorize("hasAuthority('PHYSICIAN')")
    public String adminProfile() {
        return "Welcome to Admin Profile";
    }

    @PostMapping("/generateToken")
    public String authenticateAndGetToken(@RequestBody AuthRequest authRequest) {
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(authRequest.getUsername(), authRequest.getPassword())
        );
        if (authentication.isAuthenticated()) {
            return jwtService.generateToken(authRequest.getUsername());
        } else {
            throw new UsernameNotFoundException("Invalid user request!");
        }
    }
}

