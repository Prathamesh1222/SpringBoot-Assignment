package com.hospitalModule.controller;

import com.hospitalModule.model.Patient;
import com.hospitalModule.service.PatientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/patients")
public class PatientController {

    @Autowired
    private PatientService patientService;


    @PostMapping("/register")
    @PreAuthorize("hasAuthority('PATIENT')")
    public ResponseEntity<Patient> registerPatient(@RequestBody Patient patient) {
        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        patient.setEmail(username);

        Patient createdPatient = patientService.createPatient(patient);

        // Return 201 Created with the patient object
        return new ResponseEntity<>(createdPatient, HttpStatus.CREATED);
    }


    @GetMapping
    @PreAuthorize("hasAuthority('PATIENT')")
    public ResponseEntity<List<Patient>> getAllPatients() {
        List<Patient> patients = patientService.getAllPatients();

        if (patients.isEmpty()) {
            // Return 404 Not Found if no patients exist
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

        // Return 200 OK with the list of patients
        return new ResponseEntity<>(patients, HttpStatus.OK);
    }


    @GetMapping("/{email}")
    @PreAuthorize("hasAuthority('PATIENT')")
    public ResponseEntity<Optional<Patient>> getPatientById(@PathVariable String email) {
        Optional<Patient> patient = patientService.getPatientByEmail(email);

        if (!patient.isPresent()) {
            // Return 404 Not Found if the patient does not exist
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

        // Return 200 OK with the patient data
        return new ResponseEntity<>(patient, HttpStatus.OK);
    }

    @PutMapping("/{email}")
    @PreAuthorize("hasAuthority('PATIENT')")
    public ResponseEntity<Patient> updatePatient(@PathVariable String email, @RequestBody Patient patientDetails) {
        Patient updatedPatient = patientService.updatePatient(12L, patientDetails); // You may want to update the patient lookup logic with email or user id.

        if (updatedPatient == null) {
            // Return 404 Not Found if the patient to update does not exist
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

        // Return 200 OK with the updated patient object
        return new ResponseEntity<>(updatedPatient, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAuthority('PATIENT')")
    public ResponseEntity<Void> deletePatient(@PathVariable Long id) {
        boolean isDeleted = patientService.deletePatient(id);

        if (!isDeleted) {
            // Return 404 Not Found if the patient to delete does not exist
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

        // Return 204 No Content if the deletion was successful
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }


}

