package com.hospitalModule.controller;

import com.hospitalModule.model.Physician;
import com.hospitalModule.service.PhysicianService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/physicians")
public class PhysicianController {

    @Autowired
    private PhysicianService physicianService;

    // Register a physician
    @PostMapping("/register")
    @PreAuthorize("hasAuthority('PHYSICIAN')")
    public ResponseEntity<Physician> registerPhysician(@RequestBody Physician physician) {
        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        physician.setEmail(username);

        Physician createdPhysician = physicianService.createPhysician(physician);

        // Return 201 Created with the physician object
        return new ResponseEntity<>(createdPhysician, HttpStatus.CREATED);
    }

    // Get all physicians
    @GetMapping
    @PreAuthorize("hasAuthority('PHYSICIAN')")
    public ResponseEntity<List<Physician>> getAllPhysicians() {
        List<Physician> physicians = physicianService.getAllPhysicians();

        if (physicians.isEmpty()) {
            // Return 404 Not Found if no physicians exist
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

        // Return 200 OK with the list of physicians
        return new ResponseEntity<>(physicians, HttpStatus.OK);
    }

    // Get a physician by ID
    @GetMapping("/{id}")
    @PreAuthorize("hasAuthority('PHYSICIAN')")
    public ResponseEntity<Physician> getPhysicianById(@PathVariable Long id) {
        Optional<Physician> physician = physicianService.getPhysicianById(id);

        if (!physician.isPresent()) {
            // Return 404 Not Found if the physician does not exist
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

        // Return 200 OK with the physician data
        return new ResponseEntity<>(physician.get(), HttpStatus.OK);
    }

    // Get a physician by email
    @GetMapping("/email/{email}")
    @PreAuthorize("hasAuthority('PHYSICIAN')")
    public ResponseEntity<Physician> getPhysicianByEmail(@PathVariable String email) {
        Optional<Physician> physician = physicianService.getPhysicianByEmail(email);

        if (!physician.isPresent()) {
            // Return 404 Not Found if the physician does not exist
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

        // Return 200 OK with the physician data
        return new ResponseEntity<>(physician.get(), HttpStatus.OK);
    }

    // Update a physician by ID
    @PutMapping("/{id}")
    @PreAuthorize("hasAuthority('PHYSICIAN')")
    public ResponseEntity<Physician> updatePhysician(@PathVariable Long id, @RequestBody Physician physicianDetails) {
        Physician updatedPhysician = physicianService.updatePhysician(id, physicianDetails);

        if (updatedPhysician == null) {
            // Return 404 Not Found if the physician does not exist
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

        // Return 200 OK with the updated physician
        return new ResponseEntity<>(updatedPhysician, HttpStatus.OK);
    }

    // Delete a physician by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePhysician(@PathVariable Long id) {
        boolean isDeleted = physicianService.deletePhysician(id);

        if (!isDeleted) {
            // Return 404 Not Found if the physician does not exist
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

        // Return 204 No Content if the deletion was successful
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}


