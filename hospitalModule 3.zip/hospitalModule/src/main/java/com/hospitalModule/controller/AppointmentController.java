package com.hospitalModule.controller;

import com.hospitalModule.model.Appointment;
import com.hospitalModule.service.AppointmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/api/appointments")
public class AppointmentController {

    @Autowired
    private AppointmentService appointmentService;

    @PostMapping("/create")
    @PreAuthorize("hasAuthority('PATIENT')")
    public ResponseEntity<Appointment> createAppointment(@RequestParam Long patientId,
                                                         @RequestParam Long physicianId,
                                                         @RequestParam String dateTime) {
        LocalDateTime appointmentDateTime = LocalDateTime.parse(dateTime);
        Appointment appointment = appointmentService.createAppointment(patientId, physicianId, appointmentDateTime);

        if (appointment == null) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
        return new ResponseEntity<>(appointment, HttpStatus.CREATED);
    }

    @GetMapping("/patient/{patientId}")
    @PreAuthorize("hasAuthority('PATIENT')")
    public ResponseEntity<List<Appointment>> getAppointmentsForPatient(@PathVariable Long patientId) {
        List<Appointment> appointments = appointmentService.getAppointmentsForPatient(patientId);

        if (appointments.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(appointments, HttpStatus.OK);
    }


    @GetMapping("/physician/{physicianId}")
    @PreAuthorize("hasAuthority('PATIENT')")
    public ResponseEntity<List<Appointment>> getAppointmentsForPhysician(@PathVariable Long physicianId,
                                                                         @RequestParam String startDate,
                                                                         @RequestParam String endDate) {
        LocalDateTime start = LocalDateTime.parse(startDate);
        LocalDateTime end = LocalDateTime.parse(endDate);

        List<Appointment> appointments = appointmentService.getAppointmentsForPhysician(physicianId, start, end);

        if (appointments.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(appointments, HttpStatus.OK);
    }




}


