package com.hospitalModule;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HospitalModuleApplication {

	public static void main(String[] args) {
		SpringApplication.run(HospitalModuleApplication.class, args);
	}

}
