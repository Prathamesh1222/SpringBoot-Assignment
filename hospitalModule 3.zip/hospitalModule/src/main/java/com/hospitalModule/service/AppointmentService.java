package com.hospitalModule.service;

import com.hospitalModule.model.Appointment;
import com.hospitalModule.model.Patient;
import com.hospitalModule.model.Physician;
import com.hospitalModule.repository.AppointmentRepository;
import com.hospitalModule.repository.PatientRepository;
import com.hospitalModule.repository.PhysicianRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;


@Service
public class AppointmentService {

    @Autowired
    private AppointmentRepository appointmentRepository;

    @Autowired
    private PhysicianRepository physicianRepository;

    @Autowired
    private PatientRepository patientRepository;

    public boolean isPhysicianAvailable(Long physicianId, LocalDateTime dateTime) {
        // Check if the physician is already booked for the given time slot
        List<Appointment> appointments = appointmentRepository.findByPhysicianIdAndAppointmentDateTimeBetween(
                physicianId, dateTime.minusHours(1), dateTime.plusHours(1));  // Allow a +/- 1 hour window for flexibility
        return appointments.isEmpty();  // Physician is available if no appointments exist in that time frame
    }

    public Appointment createAppointment(Long patientId, Long physicianId, LocalDateTime appointmentDateTime) {
        if (isPhysicianAvailable(physicianId, appointmentDateTime)) {
            Appointment appointment = new Appointment();

            Patient patient = patientRepository.findById(patientId).orElseThrow(() -> new RuntimeException("Patient not found"));
            appointment.setPatient(patient);  // You would fetch Patient by ID in a real-world scenario
            Physician physician = physicianRepository.findById(physicianId).orElseThrow(() -> new RuntimeException("Physician not found"));
            appointment.setPhysician(physician); // Similarly fetch Physician
            appointment.setAppointmentDateTime(appointmentDateTime);
            appointment.setStatus("Scheduled");
            return appointmentRepository.save(appointment);
        }
        return null; // Physician not available
    }

    public List<Appointment> getAppointmentsForPatient(Long patientId) {
        return appointmentRepository.findByPatientId(patientId);
    }

    public List<Appointment> getAppointmentsForPhysician(Long physicianId, LocalDateTime start, LocalDateTime end) {
        return appointmentRepository.findByPhysicianIdAndAppointmentDateTimeBetween(physicianId, start, end);
    }
}


