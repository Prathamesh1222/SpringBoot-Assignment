package com.hospitalModule.service;

import com.hospitalModule.model.Physician;
import com.hospitalModule.repository.PhysicianRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PhysicianService {

    @Autowired
    private PhysicianRepository physicianRepository;

    public Physician createPhysician(Physician physician) {
        return physicianRepository.save(physician);
    }

    public List<Physician> getAllPhysicians() {
        return physicianRepository.findAll();
    }

    public Optional<Physician> getPhysicianById(Long id) {
        return physicianRepository.findById(id);
    }

    public Optional<Physician> getPhysicianByEmail(String email) {
        return physicianRepository.findByEmail(email);
    }

    public Physician updatePhysician(Long id, Physician physicianDetails) {
        Physician physician = physicianRepository.findById(id).orElseThrow(() -> new RuntimeException("Physician not found"));
        physician.setName(physicianDetails.getName());
        physician.setSpecialization(physicianDetails.getSpecialization());
        physician.setContactNo(physicianDetails.getContactNo());
        return physicianRepository.save(physician);
    }

    public boolean deletePhysician(Long id) {
        Physician physician = physicianRepository.findById(id).orElseThrow(() -> new RuntimeException("Physician not found"));
        physicianRepository.delete(physician);
        return true;
    }
}

